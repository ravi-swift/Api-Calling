//
//  ViewController.swift
//  Api calling
//
//  Created by Rp on 29/10/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet var tbl : UITableView!
    
    var array = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.getMenu()
        
    }
    
    func getMenu()
    {
        //http://delhi.parishinfo.com/mapps/json.php
        
        let str = "http://delhi.parishinfo.com/mapps/json.php"
        
        var strUrl = String.init(format: "%@?version=22&type=login&username=%@&password=%@&install_date=&version=22&apk_os=Android",str,"F999354","Noida@82")
        
        let url = NSURL.init(string: strUrl)
        
        let request = NSMutableURLRequest.init(url: url as! URL)
        request.httpMethod = "GET"
        
        let configuartion = URLSessionConfiguration.default
        
        let session = URLSession.init(configuration: configuartion)
        
        let task =  session.dataTask(with: request as URLRequest, completionHandler: {(data,response, error) -> Void in
            
            do{
                
                let dic = try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves) as! NSDictionary
                
                self.array = dic.value(forKey: "navigation") as! NSArray
                
                DispatchQueue.main.async {
                    self.tbl.reloadData()
                }
                
                print(self.array)
                
            }catch{
                print(error)
            }
          
        })
        task.resume()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
      
        let lbl = cell.contentView.viewWithTag(1001) as! UILabel
       
        let dict = array.object(at: indexPath.row) as! NSDictionary
        
        lbl.text = dict.value(forKey: "title") as! String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

